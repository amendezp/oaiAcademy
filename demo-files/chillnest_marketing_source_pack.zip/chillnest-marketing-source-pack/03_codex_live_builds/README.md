# Codex Live Builds

Use this folder for live Codex-generated deliverables.

Suggested output files:

- `brief_v1.md`
- `creative_worlds.md`
- `moodboard_direction.md`
- `production_handoff.md`
- `starter_channel_assets.md`
- `promotion_landing_page.html`

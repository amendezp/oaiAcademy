# Chill Nest Codex for Marketing Demo

This folder contains a synthetic marketing demo for a fictional company, Chill Nest.

Chill Nest sells cooling blankets, mattress toppers, and bedding bundles for people who sleep hot during summer. The demo is designed for a 15-minute Codex enablement segment for a Marketing department.

## Demo Story

Chill Nest wants to launch a summer campaign for health-conscious millennials who want to sleep comfortably during hot weather and wake up ready for full summer days.

The working campaign direction is:

**Sleep Cool. Wake Ready.**

The audience is intentionally realistic: wellness-aware millennials who care about sleep, energy, and home comfort, but who do not want medicalized or fear-based messaging.

## Folder Map

- `01_messy_campaign_pile/` contains the raw, slightly chaotic campaign material: notes, research, brand voice, claims rules, stakeholder chatter, and mock data exports.
- `02_assets/` contains simple visual reference assets for the fake brand and products.
- `03_codex_live_builds/` is where Codex should create new demo deliverables during the live segment.
- `04_presenter_notes/` contains the presenter storyboard and prompts to paste live.
- `AGENTS.md` gives Codex durable instructions for this demo workspace.

## Intended Live Workflows

1. **Brief from the mess:** messy inputs become a useful campaign brief.
2. **Brief to creative world:** the brief becomes creative territories and moodboard direction.
3. **Creative world to handoff:** the chosen direction becomes a production handoff.
4. **Handoff to channel assets:** the handoff becomes starter assets for common campaign channels.

All data is fictional and safe for demo use.

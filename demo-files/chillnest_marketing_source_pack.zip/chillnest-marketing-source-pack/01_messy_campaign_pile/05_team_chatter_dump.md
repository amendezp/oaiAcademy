# Team Chatter Dump

Synthetic Slack-style export from `#summer-campaign-chill-nest`.

## 2026-06-02

**Maya, VP Brand:** I like "Sleep Cool. Wake Ready." It sounds more like us than "Beat the Heat." We should feel calm and confident, not alarmist.

**Theo, Growth:** Agree on calm, but heatwave hooks are what will stop thumbs. We need at least one paid angle that says "heatwave" in the first line.

**Priya, Legal:** Heatwave is okay as context. Please avoid "beat," "prevent," "stop sweating," and anything that sounds like medical relief.

**Jules, Creative Director:** Can we get three creative territories? I do not want twelve routes. Recommend: morning energy, apartment reset, warm night wind-down.

**Sam, Ecommerce:** Bundle needs to be visible above the fold. If the campaign is too soft, people will not know what to buy.

**Nina, Lifecycle:** Email can tell more of the sleep routine story. I want one launch email, one educational email, and one last-call promo email.

## 2026-06-03

**Theo, Growth:** Early paid social thought: "Hot nights are coming. Your bed can feel ready." This stays out of medical territory.

**Priya, Legal:** That is probably okay. "Your bed can feel ready" is safer than "your body can stay cool."

**Maya, VP Brand:** Please do not make this a fear campaign. Summer should feel bright and optimistic.

**Sam, Ecommerce:** I am seeing 20% off in the old tracker. Finance told me 15% max unless we cut creator spend.

**Lena, Finance:** Confirming. 15% max on bundle. No standalone blanket discount at launch.

**Nina, Lifecycle:** Promo code in one doc says SUMMERCOOL. Another says COOLREADY. Which one is final?

**Theo, Growth:** I prefer COOLREADY. It matches the campaign name.

**Priya, Legal:** Please do not use "Wake Up Recharged" unless we qualify it. It reads like an outcome claim.

## 2026-06-04

**Jules, Creative Director:** Product shots should feel real: bed, window light, fan, water glass, linen texture. No blue ice cubes. No snowflake visuals.

**Maya, VP Brand:** Yes. Also no people looking impossibly perfect at 6 a.m.

**Theo, Growth:** TikTok creator brief should include "summer bedroom reset" and "hot sleeper routine." These are natural creator phrases.

**Nina, Lifecycle:** Existing customers who bought pillows should get bundle email. They over-index on sleep-comfort content.

**Sam, Ecommerce:** Landing page needs reviews, bundle price, and size selector path. Please do not bury price.

**Priya, Legal:** Any "health-conscious" audience framing is okay internally. External copy should say comfort, routine, rest, warm nights. Avoid "health outcome."

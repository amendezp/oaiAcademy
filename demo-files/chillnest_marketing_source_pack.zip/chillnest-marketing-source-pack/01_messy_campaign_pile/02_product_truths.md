# Product Truths

Current as of synthetic planning date: 2026-06-03.

## Brand

Chill Nest makes cooling bedding for people who sleep hot and still want their bedroom to feel soft, calm, and personal.

## Product 1: ChillWeave Cooling Blanket

- SKU: CN-BLKT-CHILLWEAVE
- MSRP: $149
- Sizes: Twin/Twin XL, Full/Queen, King/California King
- Colors: Mist Blue, Cloud White, Soft Sage
- Materials: nylon-poly blend face, recycled microfiber fill
- Key features:
  - Cool-to-the-touch outer fabric
  - Lightweight breathable fill
  - Machine washable
  - Designed for warm nights and year-round hot sleepers
- Approved factual language:
  - "cool-to-the-touch"
  - "lightweight"
  - "breathable"
  - "machine washable"
  - "designed for warm nights"

## Product 2: BreezeLayer Mattress Topper

- SKU: CN-TOP-BREEZELAYER
- MSRP: $229
- Sizes: Twin/Twin XL, Full, Queen, King, California King
- Key features:
  - Airflow channel design
  - Moisture-wicking cover
  - Soft support layer
  - Elastic corner straps
  - Removable washable cover
- Approved factual language:
  - "airflow channel design"
  - "moisture-wicking cover"
  - "adds a breathable comfort layer"
  - "designed to help reduce heat buildup"

## Product 3: Summer Sleep Bundle

- SKU: CN-BNDL-SUMMER
- Includes:
  - 1 ChillWeave Cooling Blanket
  - 1 BreezeLayer Mattress Topper
- Bundle MSRP before discount: $378
- Proposed discount: 15% off
- Proposed price after discount: $321.30
- Bundle positioning:
  - The easiest way to refresh a bed for hot weather.
  - More compelling than discounting a single item.
  - Works best with calm, practical sleep-comfort messaging.

## Product Notes

- Do not call any product "medical grade."
- Do not describe the products as "climate control."
- Avoid "ice cold" because it sets the wrong expectation.
- "Cooling" is allowed as product-category language, but claims should explain the material or comfort basis.

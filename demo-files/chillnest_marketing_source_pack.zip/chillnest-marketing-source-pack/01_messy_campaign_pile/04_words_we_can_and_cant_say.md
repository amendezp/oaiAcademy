# Words We Can And Cant Say

This file is the source of truth for campaign claims.

## Approved Claim Types

The campaign may use these claim types without additional legal review if used accurately:

- Comfort claims:
  - "cool-to-the-touch"
  - "cooler-feeling"
  - "designed for warm nights"
  - "lightweight comfort"
  - "breathable comfort layer"
- Product construction claims:
  - "airflow channel design"
  - "moisture-wicking cover"
  - "machine washable"
  - "removable washable cover"
- Lifestyle claims:
  - "refresh your bedroom for summer"
  - "make warm nights feel lighter"
  - "built for hot sleepers"

## Claims Requiring Review

Use only if Legal approves exact language:

- "temperature regulating"
- "supports better sleep"
- "helps you wake up refreshed"
- "reduces overheating"
- "reduces sweating"
- "sleeps 30% cooler"
- "clinically tested"

## Prohibited Claims

Do not use these in campaign copy:

- "treats insomnia"
- "prevents night sweats"
- "guarantees deeper sleep"
- "improves health"
- "medical-grade cooling"
- "cures hot sleeping"
- "prevents overheating"
- "sleep-disorder support"

## Required Review Notes

- Customer reviews may mention personal experiences with sweating, sleep, or health. Do not turn those into brand claims.
- If using customer quote excerpts, keep them clearly attributed as customer experiences.
- Do not imply the products replace air conditioning, medical care, or sleep hygiene guidance.
- Heatwave language is acceptable as seasonal context, but avoid fear-based emergency framing.

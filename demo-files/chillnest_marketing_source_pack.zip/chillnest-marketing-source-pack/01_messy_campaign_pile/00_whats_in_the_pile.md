# What Is In The Pile

This folder is intentionally messy. It represents the kind of scattered pre-campaign material a marketing team might have before a launch.

## Files

- `01_launch_brain_dump.md`: mixed launch notes, half-decisions, old campaign names, and open questions.
- `02_product_truths.md`: current product names, product details, and approved product facts.
- `03_brand_vibe_and_voice.md`: brand voice, visual direction, and banned tone.
- `04_words_we_can_and_cant_say.md`: claims guidance and phrases that require review.
- `05_team_chatter_dump.md`: Slack-like stakeholder messages with disagreement and ambiguity.
- `06_customer_voice_clips.md`: qualitative customer research notes.
- `07_market_peek.md`: rough competitor context.
- `08_channel_asks_and_deadlines.csv`: asset needs by channel with inconsistent ownership and due dates.
- `09_sleepy_summer_survey.csv`: mock survey responses from target-adjacent consumers.
- `10_review_grab_bag.csv`: synthetic review export with customer language and recurring themes.
- `11_inventory_margin_reality_check.csv`: promo, margin, and inventory constraints.

## Known Messiness For The Demo

- The campaign name is not final. Some notes say "Cooler Nights," others say "Sleep Cool. Wake Ready."
- The launch date appears as June 24, July 1, and July 8.
- Discount guidance conflicts: 20% appears in early notes, but Finance prefers 15% max.
- Some stakeholder language drifts into risky health claims.
- Audience definition varies between "health-conscious millennials," "busy professionals," and "young parents."
- Channel ownership is inconsistent across notes and tracker rows.

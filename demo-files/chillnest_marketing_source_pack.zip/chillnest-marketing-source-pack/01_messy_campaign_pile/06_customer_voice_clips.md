# Customer Voice Clips

Synthetic qualitative notes from 12 interviews with target-adjacent consumers.

## Interview Themes

### Theme: Hot Sleep Without Wanting More AC

**Mia, 34, Austin:** "I run warm at night, but I hate blasting the AC. It feels wasteful and my partner gets cold."

**Andre, 31, Atlanta:** "My apartment holds heat. I want my bed to feel fresh when I get in, not like it has been baking all day."

**Rina, 38, Los Angeles:** "I bought linen sheets last summer because I wanted the whole room to feel lighter."

### Theme: Wellness Without Medical Language

**Sofia, 29, Denver:** "I care about sleep, but the sleep optimization stuff gets intense. I just want to not feel gross when I wake up."

**Marcus, 41, Brooklyn:** "I have a routine: shower, magnesium, phone away. Bedding is part of that, but I do not want it to sound like a health device."

**Talia, 35, Chicago:** "I am not trying to hack anything. I just want a bed that feels good in July."

### Theme: Small-Space Summer Refresh

**Dev, 32, Seattle:** "I rent, so I cannot change much. New bedding is the easiest way to make the room feel different."

**Leah, 37, Oakland:** "A lighter blanket makes the room feel calmer. I like when bedding looks intentional, not dorm-room summer."

**Cam, 30, Miami:** "I want something that still feels cozy. I do not want a scratchy athletic fabric situation."

### Theme: What Would Make Them Buy

**Pri, 33, Phoenix:** "If the bundle makes sense and I can tell what each piece does, I would consider it before peak summer."

**Jon, 39, Nashville:** "Reviews matter. I want to hear from people who run hot, not a bunch of claims."

**Avery, 28, Raleigh:** "A summer bedroom reset angle would get me. I like content that shows the whole room, not just a product floating on white."

## Researcher Notes

- Strongest emotional territory: practical relief, not transformation.
- Strongest visual territory: real bedroom, summer light, tactile bedding, small home details.
- Avoid making the audience feel like they are failing at sleep.
- "Hot sleeper" is accepted language.
- "Health-conscious" is useful internally, but customer-facing language should be more human and less clinical.

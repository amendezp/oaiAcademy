# Launch Brain Dump

Working doc compiled from meeting notes, old launch docs, and comments.

## Raw Notes

Campaign idea: "Cooler Nights" or maybe "Sleep Cool. Wake Ready."  
Summer push for cooling blanket + mattress topper bundle.  
Goal: increase bundle consideration before peak July heat.

Launch timing:

- Growth calendar says June 24 soft launch.
- Ecommerce calendar says July 1 homepage takeover.
- Retail partner wants July 8 because PDP copy is not ready.
- Paid social team says creative needs to be locked by June 17.

Audience:

- Millennials 28-42.
- Wellness-aware, health-conscious, trying to improve routines.
- They buy electrolyte powders, sunscreen, fitness apps, better pillows, reusable water bottles.
- Not "biohacker bro." More: practical, warm, design-aware, apartment/home life.
- Also maybe young parents? Nina mentioned parents in last meeting, but not sure if that is the core audience.

Main tension:

- Hot weather makes people feel tired and restless.
- They do not want to crank AC all night because of cost, noise, and sustainability guilt.
- They want their bedroom to feel calm, clean, and summer-ready.

Product:

- ChillWeave Blanket - old name? new name is ChillWeave Cooling Blanket?
- AirLoft Topper? Maybe BreezeLayer Topper? Check product sheet.
- Bundle: blanket + mattress topper, maybe 15% off.
- Blanket should be called "cool-to-the-touch," not "ice cold."
- Topper has airflow channels and moisture-wicking cover.

Potential headline ideas:

- Sleep Cool. Wake Ready.
- Make Hot Nights Feel Lighter.
- Your Summer Sleep Reset.
- Beat the Heat While You Sleep. Legal might hate "beat."
- Wake Up Recharged. Might be too claim-y?

Objectives:

- Drive awareness and consideration for cooling bedding bundle.
- Build email list for summer sleep guide.
- Lift bundle conversion during July.
- Reduce paid social CPA? Need baseline from Growth.

Initial channels:

- Paid social: Meta, TikTok.
- Email: existing customers and summer waitlist.
- Landing page: bundle story, reviews, summer sleep routine.
- Influencer: micro-creators in wellness, apartment, and home reset content.
- Retail: maybe only if partner timing works.

Messaging hierarchy draft:

1. Cooler-feeling sleep during warm nights.
2. Comfort without turning the bedroom into an AC battle.
3. Breathable materials, lightweight feel, easy summer bedroom refresh.
4. Bundle value.

Claims questions:

- Can we say "sleep deeper"?
- Can we say "supports better health"?
- Can we say "temperature-regulating"?
- Customer reviews mention night sweats, but Legal says do not lead with that.

Stakeholder snippets:

- Maya wants the campaign to feel calm and premium, not gadgety.
- Growth wants "heatwave" in the hook for relevance.
- Legal wants review of any health/wellness phrasing.
- Ecommerce wants bundle pricing visible above the fold.
- Creative wants three territories, not ten.

Open questions:

- Final campaign name.
- Final launch date.
- Whether to lead with blanket only or bundle.
- Promo code: SUMMERCOOL or COOLREADY?
- Is paid TikTok budget confirmed?
- Is "summer sleep reset" too wellness-program sounding?

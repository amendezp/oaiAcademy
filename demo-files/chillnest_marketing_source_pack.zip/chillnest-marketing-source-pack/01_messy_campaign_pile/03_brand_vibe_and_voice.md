# Brand Vibe And Voice

## Brand Positioning

Chill Nest helps warm sleepers create a cooler-feeling, calmer bedroom without turning rest into a technology project.

## Personality

- Calm
- Practical
- Fresh
- Human
- Slightly witty
- Design-aware

## Voice

Use simple, sensory language. Make the reader feel relief, softness, and ease.

Good examples:

- "A cooler-feeling bed for the nights that refuse to cool down."
- "Light layers, breathable comfort, and a bedroom that feels ready for summer."
- "For hot sleepers who still want cozy."

Avoid:

- Clinical wellness language
- Fear-heavy heatwave language
- Extreme performance claims
- Bro-y optimization language
- Overly sleepy puns

## Visual Direction

- Bright morning light
- Clean bedding textures
- Natural skin tones
- Summer windows, fans, linen, water glasses, plants
- Apartment bedrooms and small homes
- Colors: Mist Blue, Soft Sage, Cloud White, Lemon Ice, Charcoal Ink

## Banned Or Risky Tone

- "Hack your sleep"
- "Never wake up sweaty again"
- "Cure hot sleeping"
- "Guaranteed deeper sleep"
- "Stop overheating"
- "Medical-grade cooling"
- "Heatwave-proof your body"

## Suggested Campaign Territory Names

- Cool Morning Energy
- Apartment Summer Reset
- Warm Night Wind-Down

## Accessibility And Inclusion

- Show varied body types, skin tones, bedrooms, and household setups.
- Avoid implying that ideal rest requires a perfect home, expensive routine, or extreme productivity.
- Avoid shaming people for using air conditioning.

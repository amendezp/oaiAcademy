# 15-Minute Storyboard

## Segment Goal

Show a Marketing department how Codex can move campaign work from scattered inputs to real deliverables.

## What The Room Should Learn

Codex is not just a copy generator. It can read the messy pile, respect team rules, help form a point of view, and carry that thinking into creative and production work.

## Timing

### 0:00-1:30 - Set The Scene

Say:

"Chill Nest is a fictional cooling bedding company getting ready for summer. The team has the normal marketing mess: notes, research, survey data, reviews, product facts, legal guardrails, channel asks, and stakeholder opinions. We are going to move from mess to brief to creative direction to launch assets, then show how that work can become a promotion landing page."

Open:

- `README.md`
- `AGENTS.md`
- `01_messy_campaign_pile/00_whats_in_the_pile.md`
- `04_presenter_notes/prompts_to_paste_live.md`

Teaching point:

Codex can work across files and inherit the team's rules before it starts generating.

### 1:30-4:30 - Workflow 1: Brief From The Mess

Run Workflow 1.

Look for:

- What matters in the pile
- The core audience signal
- Brand-safe product truths
- Tensions and missing pieces
- A usable first brief

Teaching point:

Good campaign work starts with sensemaking, not copy.

### 4:30-7:30 - Workflow 2: Brief To Creative World

Run Workflow 2.

Look for:

- 2-3 distinct creative worlds
- Mood and visual language
- Sample lines
- A recommended direction
- A clear reason why it fits the brief

Teaching point:

Codex can help explore creative options while staying grounded in strategy.

### 7:30-10:30 - Workflow 3: Creative World To Handoff

Run Workflow 3.

Look for:

- Asset list
- Visual direction
- Copy direction
- Team-specific guidance
- Watch-outs and review needs

Teaching point:

Codex turns a creative idea into something the team can actually make.

### 10:30-13:30 - Workflow 4: Handoff To Channel Assets

Run Workflow 4.

Look for:

- Search ad copy
- Display concepts
- Meta variants
- TikTok hooks
- Email starters
- Landing page hero copy

Teaching point:

The same strategy can become many channel-native drafts without losing the thread.

### 13:30-15:00 - Workflow 5 Preview And Close

Show Workflow 5 as the next step:

```text
Turn the campaign kit into a promotion landing page I can preview. Use the chosen creative direction, include the offer, product proof, reviews, FAQs, and clear CTAs, and make it responsive. Keep the page launch-ready, but mark anything that still needs human approval.
```

Use one optional steering prompt if needed:

```text
Show me the receipts. What did you get from the files, and what are you inferring?
```

Then close with:

"The repeatable pattern is simple: give Codex the context, let it make sense of the mess, steer the judgment, and then let it carry the work into the next deliverable."

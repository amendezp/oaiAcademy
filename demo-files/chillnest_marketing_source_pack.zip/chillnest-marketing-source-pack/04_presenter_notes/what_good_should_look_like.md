# What Good Should Look Like

Use this file to rehearse the demo and evaluate whether the output is on track.

## Strong Output Should Notice

- "Sleep Cool. Wake Ready." is the safest and most brand-aligned campaign direction.
- "Beat the Heat" is punchy but riskier and less on-brand.
- The main audience is health-conscious millennials, but external messaging should avoid health outcome claims.
- The strongest insight is: people want cooler-feeling sleep without turning the bedroom into an AC battle or buying a clinical sleep gadget.
- The Summer Sleep Bundle is the right hero because it solves the whole bed and matches ecommerce needs.
- The approved discount ceiling is 15%, despite old notes mentioning 20%.
- Legal guardrails prohibit claims like "guaranteed deeper sleep," "prevents night sweats," and "improves health."
- Customer reviews can support themes, but should not be converted into brand claims.

## Brief V1 Should Include

- Clear recommendation near the top.
- Objective tied to awareness, consideration, and bundle conversion.
- Audience profile with practical motivations.
- Message hierarchy:
  1. Cooler-feeling comfort during warm nights.
  2. Breathable product construction.
  3. Summer bedroom refresh.
  4. Bundle value.
- Creative territories:
  - Cool Morning Energy
  - Apartment Summer Reset
  - Warm Night Wind-Down
- Channel plan:
  - Instagram and TikTok for discovery.
  - Email for routine education and launch conversion.
  - Landing page for bundle clarity and review support.
- Claims guardrails and review notes.
- Unresolved follow-ups.

## Creative World Should Include

- A clear mood, not just a tagline.
- Visual cues: light, texture, rooms, people, colors, pace.
- A few example lines that feel on-brand.
- A recommendation, with a reason.
- A clear "do not do this" list.

## Production Handoff Should Include

- What each team needs to make.
- How the work should feel.
- Channel-specific notes.
- Claims or legal watch-outs.
- Open approvals.

## Channel Assets Should Include

- Search ads that are direct and useful.
- Display and Meta copy that carries the idea visually.
- TikTok hooks that sound native, not like a brand deck.
- Email and landing page copy that keep the same story.
- Review flags where claims get close to the line.

## Watch-Outs

- If Codex writes medical or clinical claims, use the claims file to correct it live.
- If Codex invents survey percentages, ask it to cite or calculate from the CSV.
- If Codex ignores the finance constraint, ask it to reconcile the promo files.
- If Codex creates too much copy too early, remind the audience that strategy comes before production.

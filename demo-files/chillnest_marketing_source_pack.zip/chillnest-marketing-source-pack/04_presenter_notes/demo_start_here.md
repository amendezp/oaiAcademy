# Demo Start Here

Use this when you rehearse or present the Chill Nest demo.

## Before The Demo

Open the `chill-nest-demo` folder in Codex.

Have these files ready:

- `README.md`
- `AGENTS.md`
- `01_messy_campaign_pile/00_whats_in_the_pile.md`
- `04_presenter_notes/prompts_to_paste_live.md`

Optional visual files to show:

- `02_assets/chill_nest_brand_card.svg`
- `02_assets/chill_nest_product_reference.svg`

## Opening Talk Track

"This is a fictional campaign for Chill Nest, a cooling bedding company. The marketing team wants to launch a summer campaign for health-conscious millennials, but the inputs are scattered across notes, research, survey data, reviews, stakeholder comments, legal guidance, and channel requirements. We are going to use Codex to move from messy context to brief, creative direction, production handoff, and starter assets."

## First Prompt To Paste

```text
Help me turn this messy campaign folder into a sharp brief. First make sense of what we have, then draft the brief. Call out the tensions, missing pieces, and claims we should be careful with.
```

## What To Emphasize

- Codex reads files and project instructions, not just the latest chat message.
- The work starts with orientation and evidence, not copy generation.
- The human makes the important strategic decisions.
- Codex can preserve legal and brand guardrails across downstream deliverables.
- The same context can produce a brief, creative direction, production handoff, and channel drafts.

## Clean Demo Reset

Before a fresh run, clear generated files from `03_codex_live_builds/` except `README.md`.

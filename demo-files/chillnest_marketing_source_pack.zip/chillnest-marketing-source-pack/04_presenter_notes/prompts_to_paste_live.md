# Prompts To Paste Live

These are meant to feel reusable. Swap in a real company, campaign, folder, or audience.

## Workflow 1: Brief From The Mess

```text
Help me turn this messy campaign folder into a sharp brief. First make sense of what we have, then draft the brief. Call out the tensions, missing pieces, and claims we should be careful with.
```

## Workflow 2: Brief To Creative World

```text
Take the brief and explore a few creative worlds for the campaign. Give each one a moodboard direction, a visual language, a few sample lines, and a clear reason it could work. Recommend your favorite.
```

## Workflow 3: Creative World To Handoff

```text
Turn the chosen creative world into a production handoff for design, copy, paid media, lifecycle, and creator teams. Include the asset list, format and size guidance, visual direction, copy direction, required variants, review checkpoints, claims watch-outs, and open approvals.
```

## Workflow 4: Handoff To Channel Assets

```text
Using the brief and handoff, draft a first-pass channel kit: search ads, display copy, Meta feed/story/Reels variants, TikTok creator hooks, email subject lines and preview text, landing page hero copy, and image prompts. Keep the voice consistent, stay inside the guardrails, and flag anything that needs review.
```

## Workflow 5: Promotion Landing Page

```text
Turn the campaign kit into a promotion landing page I can preview. Use the chosen creative direction, include the offer, product proof, reviews, FAQs, and clear CTAs, and make it responsive. Keep the page launch-ready, but mark anything that still needs human approval.
```

## Optional Steering Prompts

```text
Show me the receipts. What did you get from the files, and what are you inferring?
```

```text
Make this more distinctive. Less generic bedding brand, more Chill Nest.
```

```text
Tighten this for an executive readout. Keep the thinking, lose the bulk.
```

```text
Push the creative further, but stay inside the brand and claims guardrails.
```

```text
Give me three versions: safe, sharp, and surprising.
```
